Assume
